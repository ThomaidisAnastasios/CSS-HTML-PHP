<?php
	function connect_db4() {
		$con = mysql_connect("localhost","root","");
		if (!$con) {
			die('Could not connect: ' . mysql_error());
		}
		mysql_select_db("namedate", $con) or die('Could not find the database');
	}
?>