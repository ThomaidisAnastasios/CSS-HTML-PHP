﻿<?php 
	include('connect_4.php');
	connect_db4();
	mysql_query("SET NAMES utf8");
	
	$flag = 0;
	$flag_new = 0;
	$date = date('Ymd');
	$query = mysql_query("SELECT * FROM names WHERE day='$date'") or die(mysql_error());
	while($row = mysql_fetch_array($query)) {
		$date_check = $row['day'];
		if ($date == $date_check) {
			$flag = 1;
			$date = date('m/d/Y');
			echo "Σήμερα $date γιορτάζει:"."&nbsp;".$row['celebration']."<br>";
			$celebration = $row['name'];
			$sql = mysql_query("SELECT * FROM users") or die(mysql_error());
			while($row1 = mysql_fetch_array($sql)) {
				$name = $row1['name'];
				$surname = $row1['surname'];
				$mail = $row1['mail'];
				if ($name == $celebration) {
					$flag_new = 1;
					echo "Στη βάση έχουμε εορτάζοντα"."<br>"."<br>";
					echo "Στοιχεία Εορτάζοντα:"."<br>";
					echo "&nbsp;"."&nbsp;"."&nbsp;"."Όνομα: $name ,"."&nbsp;"."Επίθετο: $surname ,"."&nbsp;"."Mail: $mail"."<br>"."<br>";
				}
			}
		}
	}
	if ($flag == 1 && $flag_new == 0) {
		echo "Στη βάση δεν έχουμε εορτάζοντα"."<br>";
	}
	$date = date('m/d/Y');
	if ($flag == 0) {
		echo "Σήμερα $date δεν γιορτάζει κανείς !"."<br>";
	}
	if ($flag_new == 1) {
		echo "Έχουν επιλεχθεί αυτόματα τα mail από τους χρήστες που γιορτάζουν σήμερα";
		echo "</br>";
		echo '<form method="post" action="namedate.php">';
		echo '<p><input type="submit" name="submit" value="Αποστολή Email στους Εορτάζοντες !"/></p>';
		echo '</form>';
	}
    mysql_query("SET NAMES utf8");
	if (isset($_POST["submit"])) {
		$query = mysql_query("SELECT * FROM users WHERE name='$celebration' ") or die(mysql_error());
		while($row = mysql_fetch_array($query)) {
			$mailto = $row['mail'];
			$to = "$mailto";
			$subject = "Χρόνια σας Πολλά!";
			$message = "Σήμερα γιορτάζετε ! Χρόνια σας πολλά !";
			$header = "aventoyris@gmail.com";
			$retval = mail($to,$subject,$message,$header);
		}
		if( $retval == true ) {
			echo "Το mail εστάλη eπιτυχώς σε όλους τους Εορτάζοντες!";
			echo "</br>";
		}
		else {
			echo "Το μήνυμα δεν εστάλη επιτυχώς στον χρήστη"."$mailto";
		}
	}
?>
