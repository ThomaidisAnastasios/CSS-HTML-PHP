<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
  <meta http-equiv="content-type" content="text/html; charset=utf-8" />
  <title>Newsletter</title>
</head>

<body>
<?php
	include ('connect.php');
	connect_db();
	$status=$_POST['status'];
	$name=$_POST['name'];
	setcookie('TestCookie', $name);
	$surname=$_POST['surname'];
	$phone=$_POST['phone'];
	$mobile=$_POST['mobile'];
	$mail=$_POST['mail'];
	$Cmail=$_POST['Cmail'];
	$password=$_POST['pass'];
	$Cpassword=$_POST['Cpass'];
	$state=$_POST['state'];
	$region=$_POST['region'];
	$address=$_POST['address'];
	$number=$_POST['number'];
	$postal=$_POST['postal'];
	$check=$_POST['check'];
	mysql_query("SET NAMES utf8"); 
	$sql="INSERT INTO information VALUES ('$status', '$name', '$surname', '$phone', '$mobile', '$mail', '$Cmail', '$password', '$Cpassword')";
	$sql1="INSERT INTO addressing VALUES ('$state', '$region', '$address', '$number', '$postal', '$check')";
	mysql_query($sql);
	mysql_query($sql1);
	echo "Χαίρετε ".$_COOKIE['TestCookie'];
	echo "<br>";
	echo "Η εισαγωγή έγινε με επιτυχία !";
?>
</body>
</html>